import functools
import copy
import os
from contextlib import contextmanager

import torch
import torch.nn as nn
import torch.nn.functional as F

import transformers
from transformers import GPT2Config, LogitsProcessorList
from transformers.pytorch_utils import Conv1D
try:
    from transformers import StoppingCriteria, StoppingCriteriaList
except Exception:
    StoppingCriteria = None
    StoppingCriteriaList = None
from tqdm import tqdm
from .transformers_gpt2 import GPT2PreTrainedModel, GPT2Model
try:
    from transformers.cache_utils import Cache as HFCache, DynamicCache
except Exception:
    HFCache = None
    DynamicCache = None

# from transformers import GPT2Config, GPT2PreTrainedModel, LogitsProcessorList
from transformers.modeling_outputs import CausalLMOutputWithCrossAttentions
from transformers.utils.model_parallel_utils import (assert_device_map,
                                                     get_device_map)

from .conformer_encoder import ConformerEncoder
from .perceiver import PerceiverResampler
from ..utils.arch_util import AttentionBlock
from ..utils.typical_sampling import TypicalLogitsWarper

try:
    from transformers.generation import GenerationMixin as HFGenerationMixin
except Exception:
    try:
        from transformers.generation.utils import GenerationMixin as HFGenerationMixin
    except Exception:
        try:
            from transformers.generation_utils import GenerationMixin as HFGenerationMixin
        except Exception:
            HFGenerationMixin = object


def null_position_embeddings(range, dim):
    return torch.zeros((range.shape[0], range.shape[1], dim), device=range.device)


def _convert_conv1d_to_linear(module):
    for name, child in list(module.named_children()):
        if isinstance(child, Conv1D):
            in_features, out_features = child.weight.shape
            linear = nn.Linear(in_features, out_features, bias=child.bias is not None, device=child.weight.device, dtype=child.weight.dtype)
            setattr(module, name, linear)
        else:
            _convert_conv1d_to_linear(child)


@contextmanager
def _temporary_default_dtype(dtype):
    if dtype is None:
        yield
        return
    prev_dtype = torch.get_default_dtype()
    if prev_dtype == dtype:
        yield
        return
    torch.set_default_dtype(dtype)
    try:
        yield
    finally:
        torch.set_default_dtype(prev_dtype)


@contextmanager
def _temporary_module_device(device_name):
    if device_name is None:
        yield
        return
    with torch.device(device_name):
        yield


def _env_enabled(name, default=True):
    raw = str(os.environ.get(name, "1" if default else "0")).strip().lower()
    return raw in ("1", "true", "yes", "y", "on")

class _TqdmTokenProgressCriteria(StoppingCriteria if StoppingCriteria is not None else object):
    def __init__(self, progress_bar, prompt_length):
        self.progress_bar = progress_bar
        self.prompt_length = int(prompt_length)
        self.last_generated = 0

    def __call__(self, input_ids, scores, **kwargs):
        if input_ids is None:
            return False
        generated = max(0, int(input_ids.shape[1]) - self.prompt_length)
        delta = generated - self.last_generated
        if delta > 0:
            self.progress_bar.update(delta)
            self.last_generated = generated
        return False

class _AbortRequestedCriteria(StoppingCriteria if StoppingCriteria is not None else object):
    def __init__(self, abort_checker):
        self.abort_checker = abort_checker

    def __call__(self, input_ids, scores, **kwargs):
        if self.abort_checker is None:
            return False
        try:
            return bool(self.abort_checker())
        except Exception:
            return False


class ResBlock(nn.Module):
    """
    Basic residual convolutional block that uses GroupNorm.
    """

    def __init__(self, chan):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(chan, chan, kernel_size=3, padding=1),
            nn.GroupNorm(chan // 8, chan),
            nn.ReLU(),
            nn.Conv1d(chan, chan, kernel_size=3, padding=1),
            nn.GroupNorm(chan // 8, chan)
        )

    def forward(self, x):
        return F.relu(self.net(x) + x)


class GPT2InferenceModel(GPT2PreTrainedModel, HFGenerationMixin):
    def __init__(self, config, gpt, text_pos_emb, embeddings, norm, linear, kv_cache=False):
        super().__init__(config)
        # Note: the argument named `text_pos_emb` here actually represents the mel position embedding
        self.transformer = gpt
        self.text_pos_embedding = text_pos_emb
        self.embeddings = embeddings
        self.final_norm = norm
        self.lm_head = nn.Sequential(norm, linear)
        self.kv_cache = kv_cache

        # Model parallel
        self.model_parallel = False
        self.device_map = None
        self.cached_mel_emb = None

    def parallelize(self, device_map=None):
        self.device_map = (
            get_device_map(len(self.transformer.h), range(max(1, torch.cuda.device_count())))
            if device_map is None
            else device_map
        )
        assert_device_map(self.device_map, len(self.transformer.h))
        self.transformer.parallelize(self.device_map)
        self.lm_head = self.lm_head.to(self.transformer.first_device)
        self.model_parallel = True

    def deparallelize(self):
        self.transformer.deparallelize()
        self.transformer = self.transformer.to("cpu")
        self.lm_head = self.lm_head.to("cpu")
        self.model_parallel = False
        torch.cuda.empty_cache()
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()

    def get_output_embeddings(self):
        return self.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.lm_head = new_embeddings

    def store_mel_emb(self, mel_emb):
        self.cached_mel_emb = mel_emb

    def prepare_inputs_for_generation(self, input_ids, past_key_values=None, **kwargs):
        token_type_ids = kwargs.get("token_type_ids", None)  # usually None
        if not self.kv_cache:
            past_key_values = None
        if (
            past_key_values is not None
            and DynamicCache is not None
            and HFCache is not None
            and not isinstance(past_key_values, HFCache)
        ):
            past_key_values = DynamicCache.from_legacy_cache(past_key_values)

        has_past = past_key_values is not None
        if has_past and HFCache is not None and isinstance(past_key_values, HFCache):
            has_past = past_key_values.get_seq_length() > 0
        # only last token for inputs_ids if past is defined in kwargs
        if has_past:
            input_ids = input_ids[:, -1].unsqueeze(-1)
            if token_type_ids is not None:
                token_type_ids = token_type_ids[:, -1].unsqueeze(-1)

        attention_mask = kwargs.get("attention_mask", None)
        position_ids = kwargs.get("position_ids", None)

        if attention_mask is not None and position_ids is None:
            # create position_ids on the fly for batch generation
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 0)
            if has_past:
                position_ids = position_ids[:, -1].unsqueeze(-1)
        else:
            position_ids = None
        return {
            "input_ids": input_ids,
            "past_key_values": past_key_values,
            "use_cache": kwargs.get("use_cache"),
            "position_ids": position_ids,
            "attention_mask": attention_mask,
            "token_type_ids": token_type_ids,
        }

    def forward(
            self,
            input_ids=None,
            past_key_values=None,
            attention_mask=None,
            token_type_ids=None,
            position_ids=None,
            head_mask=None,
            inputs_embeds=None,
            encoder_hidden_states=None,
            encoder_attention_mask=None,
            labels=None,
            use_cache=None,
            output_attentions=None,
            output_hidden_states=None,
            return_dict=None,
    ):
        assert self.cached_mel_emb is not None
        assert inputs_embeds is None  # Not supported by this inference model.
        assert labels is None  # Training not supported by this inference model.
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )
        # Create embedding
        mel_len = self.cached_mel_emb.shape[1]
        if input_ids.shape[1] != 1:
            text_inputs = input_ids[:, mel_len:]
            text_emb = self.embeddings(text_inputs)
            text_emb = text_emb + self.text_pos_embedding(text_emb)
            if self.cached_mel_emb.shape[0] != text_emb.shape[0]:
                mel_emb = self.cached_mel_emb.repeat_interleave(
                    text_emb.shape[0] // self.cached_mel_emb.shape[0], 0
                )
            else:  # this outcome only occurs once per loop in most cases
                mel_emb = self.cached_mel_emb
            emb = torch.cat([mel_emb, text_emb], dim=1)
        else:
            emb = self.embeddings(input_ids)
            emb = emb + self.text_pos_embedding.get_fixed_embedding(
                attention_mask.shape[1] - mel_len, attention_mask.device
            )
        # Under MMGP offload, runtime compute dtype can differ from raw CPU param dtype.
        # Prefer an explicit runtime dtype when available.
        target_dtype = getattr(self.transformer, "_model_dtype", None)
        try:
            if target_dtype is None:
                emb_weight = getattr(self.embeddings, "weight", None)
                if emb_weight is not None:
                    target_dtype = emb_weight.dtype
            if target_dtype is None:
                blocks = getattr(self.transformer, "h", None)
                if blocks is not None and len(blocks) > 0:
                    ln_1 = getattr(blocks[0], "ln_1", None)
                    ln_weight = getattr(ln_1, "weight", None) if ln_1 is not None else None
                    if ln_weight is not None:
                        target_dtype = ln_weight.dtype
        except Exception:
            pass
        if target_dtype is None:
            transformer_param = next(self.transformer.parameters(), None)
            if transformer_param is not None:
                target_dtype = transformer_param.dtype
        if target_dtype is not None and emb.dtype != target_dtype:
            emb = emb.to(dtype=target_dtype)
        transformer_outputs = self.transformer(
            inputs_embeds=emb,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            position_ids=position_ids,
            head_mask=head_mask,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
        )
        hidden_states = transformer_outputs[0]

        # Set device for model parallelism
        if self.model_parallel:
            if torch.backends.mps.is_available():
                self.to(self.transformer.first_device)
            else:
                torch.cuda.set_device(self.transformer.first_device)
            hidden_states = hidden_states.to(self.lm_head.weight.device)

        lm_logits = self.lm_head(hidden_states)

        if not return_dict:
            return (lm_logits,) + transformer_outputs[1:]

        return CausalLMOutputWithCrossAttentions(
            loss=None,
            logits=lm_logits,
            past_key_values=transformer_outputs.past_key_values,
            hidden_states=transformer_outputs.hidden_states,
            attentions=transformer_outputs.attentions,
            cross_attentions=transformer_outputs.cross_attentions,
        )

    @staticmethod
    def _reorder_cache(past, beam_idx):
        """
        This function is used to re-order the :obj:`past_key_values` cache if
        :meth:`~transformers.PreTrainedModel.beam_search` or :meth:`~transformers.PreTrainedModel.beam_sample` is
        called. This is required to match :obj:`past_key_values` with the correct beam_idx at every generation step.
        """
        return tuple(
            tuple(
                past_state.index_select(0, beam_idx.to(past_state.device))
                for past_state in layer_past
            )
            for layer_past in past
        )


class ConditioningEncoder(nn.Module):
    def __init__(self,
                 spec_dim,
                 embedding_dim,
                 attn_blocks=6,
                 num_attn_heads=4,
                 do_checkpointing=False,
                 mean=False):
        super().__init__()
        attn = []
        self.init = nn.Conv1d(spec_dim, embedding_dim, kernel_size=1)
        for a in range(attn_blocks):
            attn.append(AttentionBlock(embedding_dim, num_attn_heads))
        self.attn = nn.Sequential(*attn)
        self.dim = embedding_dim
        self.do_checkpointing = do_checkpointing
        self.mean = mean

    def forward(self, x):
        h = self.init(x)
        h = self.attn(h)
        if self.mean:
            return h.mean(dim=2)
        else:
            return h
            # return h[:, :, 0]


class LearnedPositionEmbeddings(nn.Module):
    def __init__(self, seq_len, model_dim, init=.02):
        super().__init__()
        self.emb = nn.Embedding(seq_len, model_dim)
        # Initializing this way is standard for GPT-2
        self.emb.weight.data.normal_(mean=0.0, std=init)

    def forward(self, x):
        sl = x.shape[1]
        return self.emb(torch.arange(0, sl, device=x.device))

    def get_fixed_embedding(self, ind, dev):
        return self.emb(torch.tensor([ind], device=dev)).unsqueeze(0)


def build_hf_gpt_transformer(layers, model_dim, heads, max_mel_seq_len, max_text_seq_len, checkpointing, build_dtype=None):
    """
    GPT-2 implemented by the HuggingFace library.
    """
    from transformers import GPT2Config, GPT2Model
    gpt_config = GPT2Config(vocab_size=256,  # Unused.
                            n_positions=max_mel_seq_len + max_text_seq_len,
                            n_ctx=max_mel_seq_len + max_text_seq_len,
                            n_embd=model_dim,
                            n_layer=layers,
                            n_head=heads,
                            gradient_checkpointing=checkpointing,
                            use_cache=not checkpointing)
    with _temporary_default_dtype(build_dtype):
        gpt = GPT2Model(gpt_config)
        mel_pos = LearnedPositionEmbeddings(max_mel_seq_len, model_dim)
        text_pos = LearnedPositionEmbeddings(max_text_seq_len, model_dim)
    # Override the built in positional embeddings
    del gpt.wpe
    gpt.wpe = functools.partial(null_position_embeddings, dim=model_dim)
    # Built-in token embeddings are unused.
    del gpt.wte
    return gpt, mel_pos, text_pos, None, None


class MelEncoder(nn.Module):
    def __init__(self, channels, mel_channels=80, resblocks_per_reduction=2):
        super().__init__()
        self.channels = channels
        self.encoder = nn.Sequential(nn.Conv1d(mel_channels, channels // 4, kernel_size=3, padding=1),
                                     nn.Sequential(*[ResBlock(channels // 4) for _ in range(resblocks_per_reduction)]),
                                     nn.Conv1d(channels // 4, channels // 2, kernel_size=3, stride=2, padding=1),
                                     nn.GroupNorm(channels // 16, channels // 2),
                                     nn.ReLU(),
                                     nn.Sequential(*[ResBlock(channels // 2) for _ in range(resblocks_per_reduction)]),
                                     nn.Conv1d(channels // 2, channels, kernel_size=3, stride=2, padding=1),
                                     nn.GroupNorm(channels // 8, channels),
                                     nn.ReLU(),
                                     nn.Sequential(*[ResBlock(channels) for _ in range(resblocks_per_reduction)]),
                                     )
        self.reduction = 4

    def forward(self, x):
        for e in self.encoder:
            x = e(x)
        return x.permute(0, 2, 1)


class UnifiedVoice(nn.Module):
    @staticmethod
    def _materialize_attention_buffers_if_meta(gpt_module):
        if gpt_module is None:
            return

        def _fix_one_attention(attn_module):
            if attn_module is None:
                return
            bias = getattr(attn_module, "bias", None)
            if torch.is_tensor(bias) and bias.device.type == "meta":
                q_len = int(bias.shape[-1]) if bias.ndim >= 2 else 0
                if q_len > 0:
                    causal = torch.tril(torch.ones((q_len, q_len), dtype=torch.bool, device="cpu")).view(1, 1, q_len, q_len)
                    attn_module.bias = causal
            masked_bias = getattr(attn_module, "masked_bias", None)
            if torch.is_tensor(masked_bias) and masked_bias.device.type == "meta":
                attn_module.masked_bias = torch.tensor(-1e4, device="cpu", dtype=torch.float32)

        blocks = getattr(gpt_module, "h", None)
        if blocks is None:
            return
        for block in blocks:
            _fix_one_attention(getattr(block, "attn", None))
            _fix_one_attention(getattr(block, "crossattention", None))

    @classmethod
    def from_config(cls, config):
        if config is None:
            return cls()
        if isinstance(config, dict):
            return cls(**config)
        if hasattr(config, "to_dict"):
            return cls(**config.to_dict())
        return cls(**dict(config))

    def __init__(self, layers=8, model_dim=512, heads=8, max_text_tokens=120, max_mel_tokens=250, max_conditioning_inputs=1,
                 mel_length_compression=1024, number_text_tokens=256,
                 start_text_token=0, stop_text_token=1, number_mel_codes=8194, start_mel_token=8192, stop_mel_token=8193,
                 train_solo_embeddings=False, use_mel_codes_as_input=True,
                 checkpointing=True, types=1,
                 condition_num_latent=32, condition_type="perceiver", condition_module=None, emo_condition_module=None, use_accel=False,
                 spk_cond_mode="conformer", num_language_tokens=107,
                 gpt_linear_layers=False, gpt_build_fp16=True, gpt_build_dtype=None, gpt_build_meta=True, force_no_flash2=False, accel_allow_vllm_kernels=False):
        """
        Args:
            layers: Number of layers in transformer stack.
            model_dim: Operating dimensions of the transformer
            heads: Number of transformer heads. Must be divisible by model_dim. Recommend model_dim//64
            max_text_tokens: Maximum number of text tokens that will be encountered by model.
            max_mel_tokens: Maximum number of MEL tokens that will be encountered by model.
            max_conditioning_inputs: Maximum number of conditioning inputs provided to the model. If (1), conditioning input can be of format (b,80,s), otherwise (b,n,80,s).
            mel_length_compression: The factor between <number_input_samples> and <mel_tokens>. Used to compute MEL code padding given wav input length.
            number_text_tokens:
            start_text_token:
            stop_text_token:
            number_mel_codes:
            start_mel_token:
            stop_mel_token:
            train_solo_embeddings:
            use_mel_codes_as_input:
            checkpointing:
            condition_type: perceiver, gst or default encoder
        """
        super().__init__()
        self.number_text_tokens = number_text_tokens
        self.start_text_token = start_text_token
        self.stop_text_token = stop_text_token
        self.number_mel_codes = number_mel_codes
        self.start_mel_token = start_mel_token
        self.stop_mel_token = stop_mel_token
        self.layers = layers
        self.heads = heads
        self.max_mel_tokens = max_mel_tokens
        self.max_text_tokens = max_text_tokens
        self.model_dim = model_dim
        self.max_conditioning_inputs = max_conditioning_inputs
        self.mel_length_compression = mel_length_compression
        self.condition_type = condition_type
        self.cond_num = condition_num_latent
        self.spk_cond_mode = spk_cond_mode
        self.gpt_linear_layers = bool(gpt_linear_layers)
        build_fp16 = bool(gpt_build_fp16 and _env_enabled("INDEXTTS2_GPT_BUILD_FP16", default=True))
        build_meta = bool(gpt_build_meta and _env_enabled("INDEXTTS2_GPT_BUILD_META", default=True))
        build_dtype = gpt_build_dtype if isinstance(gpt_build_dtype, torch.dtype) else (torch.float16 if build_fp16 else None)
        build_device = "meta" if build_meta else None
        with _temporary_module_device(build_device):
            with _temporary_default_dtype(build_dtype):
                self.cond_mask_pad = nn.ConstantPad1d((self.cond_num, 0), True)
                self.emo_cond_mask_pad = nn.ConstantPad1d((1, 0), True)
                if spk_cond_mode == "campplus":
                    self.spk_emb_proj = nn.Linear(192, model_dim)
                else:
                    if condition_type == "perceiver":
                        self.conditioning_encoder = ConditioningEncoder(1024, model_dim, num_attn_heads=heads)
                        self.perceiver_encoder = PerceiverResampler(model_dim, dim_context=model_dim, num_latents=self.cond_num)
                    elif condition_type == "conformer_perceiver" or condition_type == "conformer_encoder":
                        self.conditioning_encoder = ConformerEncoder(input_size=1024,
                                                                     output_size=condition_module['output_size'],
                                                                     linear_units=condition_module['linear_units'],
                                                                     attention_heads=condition_module['attention_heads'],
                                                                     num_blocks=condition_module['num_blocks'],
                                                                     input_layer=condition_module['input_layer'])
                        if condition_type == "conformer_perceiver":
                            self.perceiver_encoder = PerceiverResampler(model_dim, dim_context=condition_module['output_size'],
                                                                        ff_mult=condition_module['perceiver_mult'],
                                                                        heads=condition_module['attention_heads'],
                                                                        num_latents=self.cond_num)
                    else:
                        self.conditioning_encoder = ConditioningEncoder(1024, model_dim, num_attn_heads=heads, mean=True)

                self.emo_conditioning_encoder = ConformerEncoder(input_size=1024,
                                                                 output_size=emo_condition_module['output_size'],
                                                                 linear_units=emo_condition_module['linear_units'],
                                                                 attention_heads=emo_condition_module['attention_heads'],
                                                                 num_blocks=emo_condition_module['num_blocks'],
                                                                 input_layer=emo_condition_module['input_layer'])
                self.emo_perceiver_encoder = PerceiverResampler(1024, dim_context=emo_condition_module['output_size'],
                                                                    ff_mult=emo_condition_module['perceiver_mult'],
                                                                    heads=emo_condition_module['attention_heads'],
                                                                    num_latents=1)

                self.text_embedding = nn.Embedding(self.number_text_tokens * types + 1, model_dim)
                if spk_cond_mode == "campplus":
                    self.lang_embedding = nn.Embedding(num_language_tokens, model_dim)
                self.emo_layer = nn.Linear(model_dim, model_dim)
                self.emovec_layer = nn.Linear(1024, model_dim)

                if use_mel_codes_as_input:
                    self.mel_embedding = nn.Embedding(self.number_mel_codes, model_dim)
                else:
                    self.mel_embedding = MelEncoder(model_dim, resblocks_per_reduction=1)
                self.gpt, self.mel_pos_embedding, self.text_pos_embedding, self.mel_layer_pos_embedding, self.text_layer_pos_embedding = \
                    build_hf_gpt_transformer(
                        layers,
                        model_dim,
                        heads,
                        self.max_mel_tokens + 2 + self.max_conditioning_inputs,
                        self.max_text_tokens + 2,
                        checkpointing,
                        build_dtype=build_dtype,
                    )
                self._materialize_attention_buffers_if_meta(self.gpt)
                if self.gpt_linear_layers:
                    _convert_conv1d_to_linear(self.gpt)
                if train_solo_embeddings:
                    self.mel_solo_embedding = nn.Parameter(torch.randn(1, 1, model_dim) * .02, requires_grad=True)
                    self.text_solo_embedding = nn.Parameter(torch.randn(1, 1, model_dim) * .02, requires_grad=True)
                else:
                    self.mel_solo_embedding = 0
                    self.text_solo_embedding = 0

                self.final_norm = nn.LayerNorm(model_dim)
                self.text_head = nn.Linear(model_dim, self.number_text_tokens * types + 1)
                self.mel_head = nn.Linear(model_dim, self.number_mel_codes)

                if spk_cond_mode != "campplus":
                    self.speed_emb = nn.Embedding(2, model_dim)
                    self.speed_emb.weight.data.normal_(mean=0.0, std=0.0)

                # Initialize the embeddings per the GPT-2 scheme
                embeddings = [self.text_embedding]
                if use_mel_codes_as_input:
                    embeddings.append(self.mel_embedding)
                for module in embeddings:
                    module.weight.data.normal_(mean=0.0, std=.02)

        self.use_accel = use_accel
        self.force_no_flash2 = bool(force_no_flash2)
        self.accel_allow_vllm_kernels = bool(accel_allow_vllm_kernels)
        self.accel_engine = None  # Will be initialized in post_init_gpt2_config
        self.accel_flash2_available = False
        self.accel_triton_available = False
        self.accel_kernel_mode = "sdpa"

    @staticmethod
    def _install_layernorm_input_dtype_guard(module):
        if module is None or getattr(module, "_ln_input_dtype_guard", False):
            return

        def _guard(ln_module, args):
            if args is None or len(args) == 0:
                return None
            hidden_states = args[0]
            if not torch.is_tensor(hidden_states) or not torch.is_floating_point(hidden_states):
                return None
            weight = getattr(ln_module, "weight", None)
            if weight is None or hidden_states.dtype == weight.dtype:
                return None
            return (hidden_states.to(dtype=weight.dtype),) + tuple(args[1:])

        for submodule in module.modules():
            if isinstance(submodule, nn.LayerNorm):
                submodule.register_forward_pre_hook(_guard)
        module._ln_input_dtype_guard = True

    def post_init_gpt2_config(self, use_deepspeed=False, kv_cache=False, half=False, dtype=None):
        runtime_dtype = dtype if isinstance(dtype, torch.dtype) else (torch.float16 if half else torch.float32)
        seq_length = self.max_mel_tokens + self.max_text_tokens + 2
        gpt_config = GPT2Config(
            vocab_size=self.number_mel_codes,
            n_positions=seq_length,
            n_ctx=seq_length,
            n_embd=self.model_dim,
            n_layer=self.layers,
            n_head=self.heads,
            gradient_checkpointing=False,
            use_cache=True,
        )

        if self.use_accel and torch.cuda.is_available():
            from ..accel import GPT2AccelAttention, GPT2AccelModel, AccelInferenceEngine
            from ..accel.attention import configure_attention_kernels

            allow_vllm_kernels = bool(self.accel_allow_vllm_kernels)
            allow_flash2_kernel = bool(allow_vllm_kernels and (not self.force_no_flash2))
            allow_triton_kernel = bool(allow_vllm_kernels)
            configure_attention_kernels(
                allow_flash2=allow_flash2_kernel,
                allow_triton=allow_triton_kernel,
            )
            # The LM engine resolution already ran vllm probe; don't re-probe here.
            self.accel_flash2_available = allow_flash2_kernel
            self.accel_triton_available = allow_triton_kernel
            has_quantized_modules = any(hasattr(module, "qweight") for module in self.gpt.modules())
            if has_quantized_modules:
                accel_gpt = self.gpt
                for layer_index, block in enumerate(accel_gpt.h):
                    original_attention = block.attn
                    accel_attention = GPT2AccelAttention(gpt_config, layer_index)
                    accel_attention.c_attn = original_attention.c_attn
                    accel_attention.c_proj = original_attention.c_proj
                    block.attn = accel_attention
            else:
                accel_gpt = GPT2AccelModel(gpt_config)
                if self.gpt_linear_layers:
                    _convert_conv1d_to_linear(accel_gpt)
                accel_gpt.load_state_dict(self.gpt.state_dict(), strict=False)
            accel_gpt = accel_gpt.to(dtype=runtime_dtype)
            accel_gpt.eval()
            self.gpt = accel_gpt

            lm_head_with_norm = nn.Sequential(copy.deepcopy(self.final_norm), copy.deepcopy(self.mel_head))
            lm_head_with_norm = lm_head_with_norm.to(dtype=runtime_dtype)
            lm_head_with_norm.eval()
            self.gpt.lm_head_with_norm = lm_head_with_norm
            self.accel_engine = AccelInferenceEngine(
                model=self.gpt,
                lm_head=self.gpt.lm_head_with_norm,
                num_layers=self.layers,
                num_heads=self.heads,
                head_dim=self.model_dim // self.heads,
                block_size=256,
                num_blocks=16,  # Reduce to save memory (16*256 = 4096 tokens capacity)
                use_cuda_graph=True,
                dtype=runtime_dtype,
            )
            if allow_vllm_kernels and self.accel_flash2_available and self.accel_triton_available:
                self.accel_kernel_mode = "vllm"
            elif self.accel_flash2_available:
                self.accel_kernel_mode = "flash2"
            else:
                self.accel_kernel_mode = "sdpa"
            backend = self.accel_kernel_mode
            cg_state = "on"
            print(f"[IndexTTS2][accel] acceleration engine initialized (backend={backend}, cuda_graph={cg_state})")
        self.inference_model = GPT2InferenceModel(
            gpt_config,
            self.gpt,
            self.mel_pos_embedding,
            self.mel_embedding,
            self.final_norm,
            self.mel_head,
            kv_cache=kv_cache,
        )
        inference_param = next(self.inference_model.parameters(), None)
        if inference_param is not None and inference_param.dtype != runtime_dtype:
            self.inference_model = self.inference_model.to(dtype=runtime_dtype)
        self.inference_model.transformer._model_dtype = runtime_dtype
        self._install_layernorm_input_dtype_guard(self.inference_model.transformer)
        if use_deepspeed and runtime_dtype == torch.float16 and torch.cuda.is_available():
            import deepspeed
            self.ds_engine = deepspeed.init_inference(model=self.inference_model,
                                                      mp_size=1,
                                                      replace_with_kernel_inject=True,
                                                      dtype=torch.float16)
            self.inference_model = self.ds_engine.module.eval()
        elif use_deepspeed and torch.cuda.is_available():
            import deepspeed
            self.ds_engine = deepspeed.init_inference(model=self.inference_model,
                                                      mp_size=1,
                                                      replace_with_kernel_inject=True,
                                                      dtype=runtime_dtype)
            self.inference_model = self.ds_engine.module.eval()
        else:
            self.inference_model = self.inference_model.eval()

        # self.inference_model = PrunedGPT2InferenceModel(gpt_config, self.gpt, self.mel_pos_embedding, self.mel_embedding, self.final_norm, self.mel_head)
        self.gpt.wte = self.mel_embedding

    def release_runtime_generation_cache(self):
        if getattr(self, "inference_model", None) is not None:
            self.inference_model.store_mel_emb(None)
        if getattr(self, "accel_engine", None) is not None:
            self.accel_engine.release_runtime_cache()

    def build_aligned_inputs_and_targets(self, input, start_token, stop_token):
        inp = F.pad(input, (1, 0), value=start_token)
        tar = F.pad(input, (0, 1), value=stop_token)
        return inp, tar

    def set_mel_padding(self, mel_input_tokens, mel_lengths):
        """
        Given mel tokens that are derived from a padded audio clip and the actual lengths of each batch element in
        that audio clip, reformats the tokens with STOP_MEL_TOKEN in place of the zero padding. This is required
        preformatting to create a working TTS model.
        """
        for b in range(len(mel_lengths)):
            # Due to the convolutional nature of how these tokens are generated,
            # it would be best if the model predicts a token past the actual last token.
            actual_end = mel_lengths[b]
            if actual_end < mel_input_tokens.shape[-1]:
                mel_input_tokens[b, actual_end:] = self.stop_mel_token
        return mel_input_tokens

    def set_text_padding(self, text_input_tokens, text_lengths):
        """
        Given mel tokens that are derived from a padded audio clip and the actual lengths of each batch element in
        that audio clip, reformats the tokens with STOP_MEL_TOKEN in place of the zero padding. This is required
        preformatting to create a working TTS model.
        """
        for b in range(len(text_lengths)):
            # Due to the convolutional nature of how these tokens are generated,
            # it would be best if the model predicts a token past the actual last token.
            actual_end = text_lengths[b]
            if actual_end < text_input_tokens.shape[-1]:
                text_input_tokens[b, actual_end:] = self.stop_text_token
        return text_input_tokens

    def get_logits(self, speech_conditioning_inputs, first_inputs, first_head, second_inputs=None, second_head=None, get_attns=False, return_latent=False):
        if second_inputs is not None:
            emb = torch.cat([speech_conditioning_inputs, first_inputs, second_inputs], dim=1)
        else:
            emb = torch.cat([speech_conditioning_inputs, first_inputs], dim=1)

        gpt_out = self.gpt(inputs_embeds=emb, return_dict=True, output_attentions=get_attns)
        if get_attns:
            return gpt_out.attentions

        offset = speech_conditioning_inputs.shape[1]
        enc = gpt_out.last_hidden_state[:, offset:]
        enc = self.final_norm(enc)

        if return_latent:
            return enc[:, :first_inputs.shape[1]], enc[:, -second_inputs.shape[1]:]

        first_logits = enc[:, :first_inputs.shape[1]]
        first_logits = first_head(first_logits)
        first_logits = first_logits.permute(0, 2, 1)
        if second_inputs is not None:
            second_logits = enc[:, -second_inputs.shape[1]:]
            second_logits = second_head(second_logits)
            second_logits = second_logits.permute(0, 2, 1)
            return first_logits, second_logits
        else:
            return first_logits

    def get_conditioning(self, speech_conditioning_input, cond_mel_lengths=None):
        if self.condition_type == "perceiver":
            if speech_conditioning_input.ndim == 4:
                speech_conditioning_input = speech_conditioning_input.squeeze(1)
            speech_conditioning_input = self.conditioning_encoder(speech_conditioning_input)  # (b, d, s)
            conds = self.perceiver_encoder(speech_conditioning_input.transpose(1, 2))  # (b, 32, d)
        elif self.condition_type == "conformer_perceiver":
            speech_conditioning_input, mask = self.conditioning_encoder(speech_conditioning_input.transpose(1, 2),
                                                                        cond_mel_lengths)  # (b, s, d), (b, 1, s)
            if self.condition_type == "conformer_perceiver":
                # conds_mask = torch.cat([torch.ones((mask.shape[0], self.cond_num), dtype=torch.bool), mask.squeeze(1)], dim=1)
                conds_mask = self.cond_mask_pad(mask.squeeze(1))
                conds = self.perceiver_encoder(speech_conditioning_input, conds_mask)  # (b, 32, d)
        elif self.condition_type == "gst":
            if speech_conditioning_input.ndim == 4:
                speech_conditioning_input = speech_conditioning_input.squeeze(1)
            conds = self.gst_encoder(speech_conditioning_input.transpose(1, 2))  # (b, 1, d)
        else:
            speech_conditioning_input = (
                speech_conditioning_input.unsqueeze(1)
                if len(speech_conditioning_input.shape) == 3
                else speech_conditioning_input
            )
            conds = []
            for j in range(speech_conditioning_input.shape[1]):
                conds.append(self.conditioning_encoder(speech_conditioning_input[:, j]))
            conds = torch.stack(conds, dim=1)
            conds = conds.mean(dim=1)
            conds = conds.unsqueeze(1)
        return conds


    def get_emo_conditioning(self, speech_conditioning_input, cond_mel_lengths=None):
        speech_conditioning_input, mask = self.emo_conditioning_encoder(speech_conditioning_input.transpose(1, 2),
                                                                        cond_mel_lengths)  # (b, s, d), (b, 1, s)
        conds_mask = self.emo_cond_mask_pad(mask.squeeze(1))
        conds = self.emo_perceiver_encoder(speech_conditioning_input, conds_mask)  # (b, 1, d)
        return conds.squeeze(1)


    def forward(self, speech_conditioning_latent, text_inputs, text_lengths, mel_codes, mel_codes_lengths, emo_speech_conditioning_latent,
                cond_mel_lengths=None, emo_cond_mel_lengths=None, emo_vec=None, use_speed=None, do_spk_cond=False):
        """
        Forward pass that uses both text and voice in either text conditioning mode or voice conditioning mode

        speech_conditioning_input: MEL float tensor, (b,1024)
        text_inputs: long tensor, (b,t)
        text_lengths: long tensor, (b,)
        mel_inputs:  long tensor, (b,m)
        wav_lengths: long tensor, (b,)

        If return_attentions is specified, only logits are returned.
        If return_latent is specified, loss & logits are not computed or returned. Only the predicted latents are returned.
        """

        if do_spk_cond:
            if self.spk_cond_mode == "campplus":
                speech_conditioning_latent = self.spk_emb_proj(speech_conditioning_latent)
                if speech_conditioning_latent.ndim != 3:
                    speech_conditioning_latent = speech_conditioning_latent.unsqueeze(1)
            else:
                speech_conditioning_latent = self.get_conditioning(speech_conditioning_latent.transpose(1,2), cond_mel_lengths)
        else:
            speech_conditioning_latent = speech_conditioning_latent

        if emo_vec is None:
            emo_vec_syn_ori = self.get_emo_conditioning(emo_speech_conditioning_latent.transpose(1,2), emo_cond_mel_lengths)
            emo_vec_syn = self.emovec_layer(emo_vec_syn_ori)
            emo_vec = self.emo_layer(emo_vec_syn)

        text_inputs = self.set_text_padding(text_inputs, text_lengths)
        text_inputs = F.pad(text_inputs, (0, 1), value=self.stop_text_token)

        mel_codes = self.set_mel_padding(mel_codes, mel_codes_lengths)
        mel_codes = F.pad(mel_codes, (0, 1), value=self.stop_mel_token)

        if self.spk_cond_mode == "campplus":
            padding = torch.zeros(speech_conditioning_latent.size(0), 2, speech_conditioning_latent.size(2), device=speech_conditioning_latent.device, dtype=speech_conditioning_latent.dtype)
            conds = torch.cat((speech_conditioning_latent + emo_vec.unsqueeze(1), padding), 1)
        else:
            duration_emb = self.speed_emb(torch.zeros_like(use_speed))
            duration_emb_half = self.speed_emb(torch.ones_like(use_speed))
            conds = torch.cat((speech_conditioning_latent + emo_vec.unsqueeze(1), duration_emb_half.unsqueeze(1), duration_emb.unsqueeze(1)), 1)
        text_inputs, text_targets = self.build_aligned_inputs_and_targets(text_inputs, self.start_text_token, self.stop_text_token)
        text_emb = self.text_embedding(text_inputs) + self.text_pos_embedding(text_inputs)
        mel_codes, mel_targets = self.build_aligned_inputs_and_targets(mel_codes, self.start_mel_token, self.stop_mel_token)

        mel_emb = self.mel_embedding(mel_codes)
        mel_emb = mel_emb + self.mel_pos_embedding(mel_codes)

        text_logits, mel_logits = self.get_logits(conds, text_emb, self.text_head, mel_emb, self.mel_head, get_attns=False, return_latent=True)
        return mel_logits[:, :-2]  # Despite the name, these are not logits. Strip off the two tokens added by this forward pass.

    def prepare_gpt_inputs(
        self,
        conditional_latents: torch.Tensor,
        text_inputs: torch.Tensor,
        langs: torch.Tensor = None,
    ):
        
        """
        Prepare the inputs for the GPT2InferenceModel to generate.
        Args:
            conds_latent: (b, 32, dim) audio conditioning embedding by `get_conditioning()`
            text_inputs: (b, L)
        Returns:
            input_ids: (b, s+1) the input ids for the GPT2InferenceModel.generate()
            inputs_embeds: (b, s+1, dim) the input embeddings for the GPT2InferenceModel.forward()
            attention_mask: (b, s+1) the attention mask for the GPT2InferenceModel.generate()
        """
        b, L = text_inputs.shape[:2]
        device = text_inputs.device
        single_cond = conditional_latents.ndim == 3 and conditional_latents.shape[0] == 1
        if not single_cond:
            assert conditional_latents.shape[0] == b, f"batch size mismatch: {conditional_latents.shape[0]} vs {b}"
        batched_mel_emb = []
        attention_masks = []
        target_len = conditional_latents.shape[1] + L + 2
        for i in range(b):
            valid_mask = (text_inputs[i] != self.stop_text_token) & (text_inputs[i] != self.start_text_token)
            text_input = text_inputs[i][valid_mask]
            text_input = F.pad(text_input, (1, 0), value=self.start_text_token)
            text_input = F.pad(text_input, (0, 1), value=self.stop_text_token)
            text_input_pos = torch.arange(0, text_input.size(-1), device=device)
            text_emb = self.text_embedding(text_input) + self.text_pos_embedding.emb(text_input_pos)
            if self.spk_cond_mode == "campplus":
                lang_id = langs[0] if langs.numel() == 1 else langs[i]
                text_emb = text_emb + self.lang_embedding(lang_id)
            # concatenate [conditional latents][text embeddings]
            conds_text_emb = [
                conditional_latents.squeeze(0) if single_cond else conditional_latents[i],
                text_emb,
            ]
            # +1 for the start_mel_token
            attention_mask = torch.ones(target_len+1, dtype=torch.long, device=device)
            # check this text input is padded
            padding: int = L + 2 - text_input.size(-1)
            # pad left of [cond][text] -> [pad][cond][text]
            if padding > 0:
                pad = torch.zeros((padding, conditional_latents.size(-1)), dtype=text_emb.dtype, device=device) # [p, dim]
                conds_text_emb.insert(0, pad)
                attention_mask[:padding] = 0
            mel_emb = torch.cat(conds_text_emb) #[s, dim]
            assert mel_emb.shape[0] == target_len, f"mel_emb.shape: {mel_emb.shape}, target_len: {target_len}"
            batched_mel_emb.append(mel_emb)
            attention_masks.append(attention_mask)
        # [b, s, dim]
        batched_mel_emb = torch.stack(batched_mel_emb, dim=0)
        # [b, s+1]
        attention_mask = torch.stack(attention_masks, dim=0)
        # [b, s+1]
        fake_inputs = torch.ones(
            (
                batched_mel_emb.shape[0],
                batched_mel_emb.shape[1] + 1,  # +1 for the start_mel_token
            ),
            dtype=torch.long,
            device=device,
        )
        fake_inputs[:, -1] = self.start_mel_token
        return fake_inputs, batched_mel_emb, attention_mask

    def inference_speech(self, speech_condition, text_inputs, emo_speech_condition=None, cond_lengths=None, emo_cond_lengths=None, emo_vec=None, use_speed=False, input_tokens=None, num_return_sequences=1,
                         abort_checker=None,
                         max_generate_length=None, typical_sampling=False, typical_mass=.9, langs=None, campplus_embedding=None, **hf_generate_kwargs):
        """
        Args:
            speech_condition: (b, d, frames) or (d, frames)
            text_inputs: (b, L)
            cond_mel_lengths: lengths of the conditioning mel spectrograms in shape (b,) or (1,)
            input_tokens: additional tokens for generation in shape (b, s) or (s,)
            max_generate_length: limit the number of generated tokens
            hf_generate_kwargs: kwargs for `GPT2InferenceModel.generate(**hf_generate_kwargs)`
        """

        if speech_condition.ndim == 2:
            speech_condition = speech_condition.unsqueeze(0)
        if emo_speech_condition is None:
            emo_speech_condition = speech_condition
        if cond_lengths is None:
            cond_lengths = torch.tensor([speech_condition.shape[-1]], device=speech_condition.device)
        if emo_cond_lengths is None:
            emo_cond_lengths = torch.tensor([emo_speech_condition.shape[-1]], device=speech_condition.device) 

        if self.spk_cond_mode == "campplus":
            speech_conditioning_latent = self.spk_emb_proj(campplus_embedding)
            if speech_conditioning_latent.ndim != 3:
                speech_conditioning_latent = speech_conditioning_latent.unsqueeze(1)
        else:
            speech_conditioning_latent = self.get_conditioning(speech_condition.transpose(1,2), cond_lengths)
        if emo_vec is None:
            print('compute emo vec')
            emo_vec = self.get_emo_conditioning(emo_speech_condition.transpose(1,2), emo_cond_lengths)
            emo_vec = self.emovec_layer(emo_vec)
            emo_vec = self.emo_layer(emo_vec)

        target_device = speech_conditioning_latent.device
        if text_inputs.device != target_device:
            text_inputs = text_inputs.to(target_device)
        if self.spk_cond_mode == "campplus":
            padding = torch.zeros(speech_conditioning_latent.size(0), 2, speech_conditioning_latent.size(2), device=target_device, dtype=speech_conditioning_latent.dtype)
            conds_latent = torch.cat((speech_conditioning_latent + emo_vec.unsqueeze(1), padding), 1)
        else:
            tmp = torch.zeros(text_inputs.size(0), device=target_device)
            duration_emb = self.speed_emb(torch.zeros_like(tmp).long())
            duration_emb_half = self.speed_emb(torch.ones_like(tmp).long())
            conds_latent = torch.cat((speech_conditioning_latent + emo_vec.unsqueeze(1), duration_emb_half.unsqueeze(1), duration_emb.unsqueeze(1)), 1)
        input_ids, inputs_embeds, attention_mask = self.prepare_gpt_inputs(conds_latent, text_inputs, langs=langs)
        self.inference_model.store_mel_emb(inputs_embeds)
        if input_tokens is None:
            inputs = input_ids
        else:
            if input_tokens.ndim == 1:
                input_tokens = input_tokens.unsqueeze(0)
            assert num_return_sequences % input_tokens.shape[0] == 0, \
                    "The num_return_sequences must be divisible by the batch number of input_tokens"
            assert num_return_sequences % text_inputs.shape[0] == 0, \
                    "The num_return_sequences must be divisible by the batch number of text_inputs"
            b = num_return_sequences // input_ids.shape[0]
            if b > 1:
                input_ids = input_ids.repeat(b, 1)
                attention_mask = attention_mask.repeat(b, 1)
            input_tokens = input_tokens.repeat(num_return_sequences // input_tokens.shape[0], 1)
            inputs = torch.cat([input_ids, input_tokens], dim=1)
            attention_mask = F.pad(attention_mask, (0, input_tokens.shape[1]), value=1)
        trunc_index = inputs.shape[1]
        logits_processor = LogitsProcessorList()
        if typical_sampling:
            # employ custom typical sampling
            if not (typical_mass > 0.0 and typical_mass < 1.0):
                raise ValueError(f"`typical_mass` has to be a float > 0 and < 1, but is {typical_mass}")
            min_tokens_to_keep = 2 if hf_generate_kwargs.get("num_beams", 1) > 1 else 1
            logits_processor.append(TypicalLogitsWarper(mass=typical_mass, min_tokens_to_keep=min_tokens_to_keep))
        max_length = (trunc_index + self.max_mel_tokens - 1) if max_generate_length is None else trunc_index + max_generate_length
        cg_max_total_tokens = hf_generate_kwargs.pop("cg_max_total_tokens", None)
        if cg_max_total_tokens is None:
            prompt_budget = int(self.cond_num + self.max_text_tokens + 3)
            gen_budget = int(self.max_mel_tokens if max_generate_length is None else max_generate_length)
            cg_max_total_tokens = prompt_budget + max(1, gen_budget)
        
        try:
            # Use accel engine if available (single sequence only)
            if self.accel_engine is not None and num_return_sequences == 1:
                output = self.accel_engine.generate(
                    inputs,  # fake input_ids (all 1s + start_mel_token)
                    max_new_tokens=max_length - trunc_index,
                    attention_mask=attention_mask,
                    temperature=hf_generate_kwargs.get('temperature', 1),
                    top_k=hf_generate_kwargs.get("top_k", 50),
                    top_p=hf_generate_kwargs.get("top_p", 1.0),
                    stop_tokens=[self.stop_mel_token],
                    tts_embeddings=inputs_embeds,  # [pad][cond][text] embeddings (87 tokens, NO start_mel_token)
                    tts_mel_embedding=self.inference_model.embeddings,  # mel_embedding layer
                    tts_text_pos_embedding=self.inference_model.text_pos_embedding,  # text_pos_embedding layer
                    cg_max_total_tokens=int(cg_max_total_tokens),
                    stop_checker=abort_checker,
                )
            else:
                token_progress = tqdm(total=int(max(1, max_length - trunc_index)), desc="transformer_tokens", unit="tok", leave=True)
                stopping_criteria = hf_generate_kwargs.pop("stopping_criteria", None)
                if StoppingCriteriaList is not None:
                    if stopping_criteria is None:
                        stopping_criteria = StoppingCriteriaList()
                    elif not isinstance(stopping_criteria, StoppingCriteriaList):
                        stopping_criteria = StoppingCriteriaList(stopping_criteria)
                    if StoppingCriteria is not None:
                        stopping_criteria.append(_TqdmTokenProgressCriteria(token_progress, trunc_index))
                        if abort_checker is not None:
                            stopping_criteria.append(_AbortRequestedCriteria(abort_checker))
                try:
                    output = self.inference_model.generate(inputs,
                                                        bos_token_id=self.start_mel_token, pad_token_id=self.stop_mel_token,
                                                        eos_token_id=self.stop_mel_token, attention_mask=attention_mask,
                                                        max_length=max_length, logits_processor=logits_processor,
                                                        num_return_sequences=num_return_sequences,
                                                        stopping_criteria=stopping_criteria,
                                                        **hf_generate_kwargs)
                finally:
                    token_progress.close()
            if isinstance(output, torch.Tensor):
                return output[:, trunc_index:], speech_conditioning_latent
            # GenerateOutput
            output.sequences = output.sequences[:, trunc_index:]
            return output, speech_conditioning_latent
        finally:
            self.inference_model.store_mel_emb(None)

    def get_emovec(self, emo_speech_conditioning_latent, emo_cond_lengths):
        emo_vec_syn_ori = self.get_emo_conditioning(emo_speech_conditioning_latent.transpose(1,2), emo_cond_lengths)
        emo_vec_syn = self.emovec_layer(emo_vec_syn_ori)
        emo_vec = self.emo_layer(emo_vec_syn)
        return emo_vec

    def merge_emovec(self, speech_conditioning_latent, emo_speech_conditioning_latent, cond_lengths, emo_cond_lengths, alpha = 1.0):
        emo_vec = self.get_emovec(emo_speech_conditioning_latent, emo_cond_lengths)
        base_vec = self.get_emovec(speech_conditioning_latent, cond_lengths)

        out = base_vec + alpha * (emo_vec - base_vec)
        return out
