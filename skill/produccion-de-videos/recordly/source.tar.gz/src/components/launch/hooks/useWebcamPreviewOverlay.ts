import { type PointerEvent, useCallback, useEffect, useRef, useState } from "react";
import {
	canShowFloatingWebcamPreview,
	DEFAULT_WEBCAM_PREVIEW_SIZE,
	parseWebcamPreviewSize,
	resizeWebcamPreview,
	WEBCAM_PREVIEW_SIZE_STORAGE_KEY,
	type WebcamPreviewResizeHandle,
} from "../floatingWebcamPreview";
import { shouldRestoreHudMousePassthroughAfterDrag } from "../hudMousePassthrough";

const WEBCAM_PREVIEW_DRAG_THRESHOLD = 6;
const DEFAULT_WEBCAM_PREVIEW_OFFSET = { x: 0, y: 0 };

export function useWebcamPreviewOverlay({
	webcamEnabled,
	webcamDeviceId,
	showWebcamControls,
	webcamPopoverOpen,
	hudOverlayMousePassthroughSupported,
}: {
	webcamEnabled: boolean;
	webcamDeviceId?: string;
	showWebcamControls: boolean;
	webcamPopoverOpen: boolean;
	hudOverlayMousePassthroughSupported: boolean | null;
}) {
	const [editorMode, setEditorMode] = useState(true);
	useEffect(() => {
		let active = true;
		let receivedEvent = false;
		const unsubscribe = window.electronAPI.onEditorModeChanged((inEditor) => {
			receivedEvent = true;
			if (active) setEditorMode(inEditor);
		});
		void window.electronAPI
			.getEditorMode()
			.then((inEditor) => {
				if (active && !receivedEvent) setEditorMode(inEditor);
			})
			.catch(() => {
				/* Keep the camera off if editor mode is unknown. */
			});
		return () => {
			active = false;
			unsubscribe();
		};
	}, []);
	const [showFloatingWebcamPreview, setShowFloatingWebcamPreview] = useState(true);
	const [webcamPreviewOffset, setWebcamPreviewOffset] = useState(DEFAULT_WEBCAM_PREVIEW_OFFSET);
	const webcamPreviewOffsetRef = useRef(DEFAULT_WEBCAM_PREVIEW_OFFSET);
	const [webcamPreviewSize, setWebcamPreviewSize] = useState(() => {
		try {
			return parseWebcamPreviewSize(localStorage.getItem(WEBCAM_PREVIEW_SIZE_STORAGE_KEY));
		} catch {
			return DEFAULT_WEBCAM_PREVIEW_SIZE;
		}
	});
	const webcamPreviewResizeRef = useRef<{
		pointerId: number;
		handle: WebcamPreviewResizeHandle;
		startX: number;
		startY: number;
		startRect: DOMRect;
		startOffset: { x: number; y: number };
		size: { width: number; height: number };
	} | null>(null);
	const webcamPreviewRef = useRef<HTMLVideoElement | null>(null);
	const recordingWebcamPreviewRef = useRef<HTMLVideoElement | null>(null);
	const recordingWebcamPreviewContainerRef = useRef<HTMLDivElement | null>(null);
	const previewStreamRef = useRef<MediaStream | null>(null);
	const previewDragMoveRafRef = useRef<number | null>(null);
	const previewDragPendingPointerRef = useRef<{ clientX: number; clientY: number } | null>(null);
	const webcamPreviewDragStartRef = useRef<{
		pointerId: number;
		startX: number;
		startY: number;
		originX: number;
		originY: number;
		initialLeft: number;
		initialTop: number;
		previewWidth: number;
		previewHeight: number;
		dragging: boolean;
	} | null>(null);
	const isWebcamPreviewDraggingRef = useRef(false);
	const showRecordingWebcamPreview =
		webcamEnabled &&
		canShowFloatingWebcamPreview(
			showFloatingWebcamPreview,
			hudOverlayMousePassthroughSupported,
		);
	const shouldStreamWebcamPreview =
		!editorMode &&
		webcamEnabled &&
		(showRecordingWebcamPreview || (showWebcamControls && webcamPopoverOpen));

	useEffect(() => {
		if (!webcamEnabled) {
			webcamPreviewOffsetRef.current = DEFAULT_WEBCAM_PREVIEW_OFFSET;
			setWebcamPreviewOffset(DEFAULT_WEBCAM_PREVIEW_OFFSET);
			if (recordingWebcamPreviewContainerRef.current) {
				recordingWebcamPreviewContainerRef.current.style.transform = "translate(0px, 0px)";
			}
			webcamPreviewDragStartRef.current = null;
			isWebcamPreviewDraggingRef.current = false;
			setShowFloatingWebcamPreview(true);
		}
	}, [webcamEnabled]);

	const handleWebcamPreviewPointerDown = useCallback((event: PointerEvent<HTMLDivElement>) => {
		if (event.button !== 0) {
			return;
		}

		const previewRect = event.currentTarget.getBoundingClientRect();

		event.preventDefault();
		window.electronAPI?.hudOverlaySetIgnoreMouse?.(false);
		webcamPreviewDragStartRef.current = {
			pointerId: event.pointerId,
			startX: event.clientX,
			startY: event.clientY,
			originX: webcamPreviewOffsetRef.current.x,
			originY: webcamPreviewOffsetRef.current.y,
			initialLeft: previewRect.left,
			initialTop: previewRect.top,
			previewWidth: previewRect.width,
			previewHeight: previewRect.height,
			dragging: false,
		};
		event.currentTarget.setPointerCapture(event.pointerId);
	}, []);

	const handleWebcamPreviewPointerMove = useCallback((event: PointerEvent<HTMLDivElement>) => {
		const dragState = webcamPreviewDragStartRef.current;
		if (!dragState || dragState.pointerId !== event.pointerId) {
			return;
		}

		const deltaX = event.clientX - dragState.startX;
		const deltaY = event.clientY - dragState.startY;

		if (!dragState.dragging && Math.hypot(deltaX, deltaY) < WEBCAM_PREVIEW_DRAG_THRESHOLD) {
			return;
		}

		if (!dragState.dragging) {
			dragState.dragging = true;
			isWebcamPreviewDraggingRef.current = true;
		}

		previewDragPendingPointerRef.current = { clientX: event.clientX, clientY: event.clientY };
		if (previewDragMoveRafRef.current !== null) {
			return;
		}

		previewDragMoveRafRef.current = requestAnimationFrame(() => {
			previewDragMoveRafRef.current = null;
			const latestDragState = webcamPreviewDragStartRef.current;
			const pointer = previewDragPendingPointerRef.current;
			if (!latestDragState || !pointer) {
				return;
			}

			const latestDeltaX = pointer.clientX - latestDragState.startX;
			const latestDeltaY = pointer.clientY - latestDragState.startY;
			// Pointer coordinates and getBoundingClientRect() are relative to the HUD
			// viewport. `screen.width` can use a different display/DPI coordinate space.
			const viewportWidth = window.innerWidth;
			const viewportHeight = window.innerHeight;
			const unclampedLeft = latestDragState.initialLeft + latestDeltaX;
			const unclampedTop = latestDragState.initialTop + latestDeltaY;
			const clampedLeft = Math.min(
				Math.max(0, unclampedLeft),
				Math.max(0, viewportWidth - latestDragState.previewWidth),
			);
			const clampedTop = Math.min(
				Math.max(0, unclampedTop),
				Math.max(0, viewportHeight - latestDragState.previewHeight),
			);

			const nextOffset = {
				x: latestDragState.originX + (clampedLeft - latestDragState.initialLeft),
				y: latestDragState.originY + (clampedTop - latestDragState.initialTop),
			};
			webcamPreviewOffsetRef.current = nextOffset;
			if (recordingWebcamPreviewContainerRef.current) {
				recordingWebcamPreviewContainerRef.current.style.transform = `translate(${nextOffset.x}px, ${nextOffset.y}px)`;
			}
		});
	}, []);

	const handleWebcamPreviewPointerUp = useCallback((event: PointerEvent<HTMLDivElement>) => {
		const dragState = webcamPreviewDragStartRef.current;
		if (!dragState || dragState.pointerId !== event.pointerId) {
			return;
		}
		if (previewDragMoveRafRef.current !== null) {
			cancelAnimationFrame(previewDragMoveRafRef.current);
			previewDragMoveRafRef.current = null;
		}
		previewDragPendingPointerRef.current = null;

		const wasDragging = dragState.dragging;
		webcamPreviewDragStartRef.current = null;
		isWebcamPreviewDraggingRef.current = false;
		setWebcamPreviewOffset({ ...webcamPreviewOffsetRef.current });
		if (event.currentTarget.hasPointerCapture(event.pointerId)) {
			event.currentTarget.releasePointerCapture(event.pointerId);
		}
		if (wasDragging) {
			window.electronAPI?.hudOverlaySetIgnoreMouse?.(true);
		}
	}, []);

	const handleWebcamPreviewResizePointerDown = useCallback(
		(event: PointerEvent<HTMLDivElement>) => {
			const container = recordingWebcamPreviewContainerRef.current;
			if (event.button !== 0 || !container) {
				return;
			}

			// Keep the container's drag handler from treating this as a move.
			event.preventDefault();
			event.stopPropagation();
			window.electronAPI?.hudOverlaySetIgnoreMouse?.(false);
			isWebcamPreviewDraggingRef.current = true;
			webcamPreviewResizeRef.current = {
				pointerId: event.pointerId,
				handle: event.currentTarget.dataset.resizeHandle as WebcamPreviewResizeHandle,
				startX: event.clientX,
				startY: event.clientY,
				startRect: container.getBoundingClientRect(),
				startOffset: webcamPreviewOffsetRef.current,
				size: webcamPreviewSize,
			};
			event.currentTarget.setPointerCapture(event.pointerId);
		},
		[webcamPreviewSize],
	);

	const handleWebcamPreviewResizePointerMove = useCallback(
		(event: PointerEvent<HTMLDivElement>) => {
			const resizeState = webcamPreviewResizeRef.current;
			const container = recordingWebcamPreviewContainerRef.current;
			if (!resizeState || resizeState.pointerId !== event.pointerId || !container) {
				return;
			}

			const { width, height, shiftX, shiftY } = resizeWebcamPreview(
				resizeState.handle,
				resizeState.startRect,
				event.clientX - resizeState.startX,
				event.clientY - resizeState.startY,
				{ width: window.innerWidth, height: window.innerHeight },
			);
			resizeState.size = { width, height };
			webcamPreviewOffsetRef.current = {
				x: resizeState.startOffset.x + shiftX,
				y: resizeState.startOffset.y + shiftY,
			};
			container.style.width = `${width}px`;
			container.style.height = `${height}px`;
			container.style.transform = `translate(${webcamPreviewOffsetRef.current.x}px, ${webcamPreviewOffsetRef.current.y}px)`;
		},
		[],
	);

	const handleWebcamPreviewResizePointerUp = useCallback(
		(event: PointerEvent<HTMLDivElement>) => {
			const resizeState = webcamPreviewResizeRef.current;
			if (!resizeState || resizeState.pointerId !== event.pointerId) {
				return;
			}

			webcamPreviewResizeRef.current = null;
			isWebcamPreviewDraggingRef.current = false;
			setWebcamPreviewSize(resizeState.size);
			setWebcamPreviewOffset({ ...webcamPreviewOffsetRef.current });
			try {
				localStorage.setItem(
					WEBCAM_PREVIEW_SIZE_STORAGE_KEY,
					JSON.stringify(resizeState.size),
				);
			} catch {
				// Keep resizing and pointer cleanup working when preferences cannot be saved.
			}
			if (event.currentTarget.hasPointerCapture(event.pointerId)) {
				event.currentTarget.releasePointerCapture(event.pointerId);
			}
			const previewBounds =
				recordingWebcamPreviewContainerRef.current?.getBoundingClientRect();
			if (
				shouldRestoreHudMousePassthroughAfterDrag(
					previewBounds ?? null,
					event.clientX,
					event.clientY,
				)
			) {
				window.electronAPI?.hudOverlaySetIgnoreMouse?.(true);
			}
		},
		[],
	);

	const attachPreviewStreamToNode = useCallback((videoElement: HTMLVideoElement | null) => {
		const previewStream = previewStreamRef.current;
		if (!videoElement || !previewStream || videoElement.srcObject === previewStream) {
			return;
		}

		videoElement.srcObject = previewStream;
		const playPromise = videoElement.play();
		if (playPromise) {
			playPromise.catch(() => {
				// Ignore autoplay interruptions while the preview element mounts.
			});
		}
	}, []);

	const setWebcamPreviewNode = useCallback(
		(node: HTMLVideoElement | null) => {
			webcamPreviewRef.current = node;
			attachPreviewStreamToNode(node);
		},
		[attachPreviewStreamToNode],
	);

	const setRecordingWebcamPreviewNode = useCallback(
		(node: HTMLVideoElement | null) => {
			recordingWebcamPreviewRef.current = node;
			attachPreviewStreamToNode(node);
		},
		[attachPreviewStreamToNode],
	);

	useEffect(() => {
		return () => {
			if (previewDragMoveRafRef.current !== null) {
				cancelAnimationFrame(previewDragMoveRafRef.current);
			}
			previewDragMoveRafRef.current = null;
			previewDragPendingPointerRef.current = null;
		};
	}, []);

	useEffect(() => {
		let mounted = true;

		const startPreview = async () => {
			if (!shouldStreamWebcamPreview) {
				return;
			}

			try {
				const previewStream = await navigator.mediaDevices.getUserMedia({
					video: webcamDeviceId
						? {
								deviceId: { exact: webcamDeviceId },
								width: { ideal: 320 },
								height: { ideal: 320 },
								frameRate: { ideal: 24, max: 30 },
							}
						: {
								width: { ideal: 320 },
								height: { ideal: 320 },
								frameRate: { ideal: 24, max: 30 },
							},
					audio: false,
				});

				if (!mounted) {
					previewStream.getTracks().forEach((track) => track.stop());
					return;
				}

				previewStreamRef.current = previewStream;
				attachPreviewStreamToNode(webcamPreviewRef.current);
				attachPreviewStreamToNode(recordingWebcamPreviewRef.current);
			} catch (error) {
				console.warn("Failed to start live webcam preview:", error);
			}
		};

		void startPreview();

		return () => {
			mounted = false;
			const previewNode = webcamPreviewRef.current;
			const recordingPreviewNode = recordingWebcamPreviewRef.current;
			const previewStream = previewStreamRef.current;

			[previewNode, recordingPreviewNode]
				.filter((node): node is HTMLVideoElement => Boolean(node))
				.forEach((videoElement) => {
					videoElement.pause();
					videoElement.srcObject = null;
				});
			previewStream?.getTracks().forEach((track) => track.stop());
			if (previewStreamRef.current === previewStream) {
				previewStreamRef.current = null;
			}
		};
	}, [attachPreviewStreamToNode, shouldStreamWebcamPreview, webcamDeviceId]);

	return {
		showFloatingWebcamPreview,
		setShowFloatingWebcamPreview,
		webcamPreviewOffset,
		webcamPreviewSize,
		recordingWebcamPreviewContainerRef,
		isWebcamPreviewDraggingRef,
		webcamPreviewDragStartRef,
		handleWebcamPreviewPointerDown,
		handleWebcamPreviewPointerMove,
		handleWebcamPreviewPointerUp,
		handleWebcamPreviewResizePointerDown,
		handleWebcamPreviewResizePointerMove,
		handleWebcamPreviewResizePointerUp,
		setWebcamPreviewNode,
		setRecordingWebcamPreviewNode,
		showRecordingWebcamPreview,
	};
}
