declare module "uiohook-napi";
